﻿namespace SIS.MvcFramework.Logger
{
    public interface ILogger
    {
        void Log(string message);
    }
}
