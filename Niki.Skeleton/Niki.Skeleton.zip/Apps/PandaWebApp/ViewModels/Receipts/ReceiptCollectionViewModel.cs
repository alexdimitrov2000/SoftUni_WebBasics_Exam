﻿using System.Collections.Generic;

namespace PandaWebApp.ViewModels.Receipts
{
    public class ReceiptCollectionViewModel
    {
        public List<ReceiptDetailsViewModel> Receipts { get; set; }
    }
}
