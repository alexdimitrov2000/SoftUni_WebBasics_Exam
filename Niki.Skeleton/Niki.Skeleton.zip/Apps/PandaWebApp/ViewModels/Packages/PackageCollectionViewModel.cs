﻿using System.Collections.Generic;

namespace PandaWebApp.ViewModels.Packages
{
    public class PackageCollectionViewModel
    {
        public List<PackageViewModel> Packages { get; set; }
    }
}
