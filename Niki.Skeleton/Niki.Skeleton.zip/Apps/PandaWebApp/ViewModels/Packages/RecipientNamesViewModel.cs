﻿using System.Collections.Generic;

namespace PandaWebApp.ViewModels.Packages
{
    public class RecipientNamesViewModel
    {
        public List<string> Recipients { get; set; }
    }
}
