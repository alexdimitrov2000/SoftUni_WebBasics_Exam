﻿namespace PandaWebApp.ViewModels.Home
{
    public class IndexPackageViewModel
    {
        public int Id { get; set; }

        public string Description { get; set; }
    }
}
