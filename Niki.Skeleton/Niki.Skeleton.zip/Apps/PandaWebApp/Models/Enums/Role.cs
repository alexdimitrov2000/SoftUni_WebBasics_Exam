﻿namespace PandaWebApp.Models.Enums
{
    public enum Role
    {
        User,
        Admin
    }
}
