﻿namespace PandaWebApp.Models.Enums
{
    public enum PackageStatus
    {
        Pending,
        Shipped,
        Delivered,
        Acquired
    }
}
